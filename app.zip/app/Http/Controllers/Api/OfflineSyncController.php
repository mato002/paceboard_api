<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Jobs\ProcessTripAnalytics;
use App\Models\Trip;
use App\Models\TripPoint;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OfflineSyncController extends Controller
{
    public function sync(Request $request)
    {
        $request->validate([
            'trips' => 'required|array|min:1|max:10',
            'trips.*.local_id' => 'required|string',
            'trips.*.name' => 'nullable|string|max:255',
            'trips.*.start_city' => 'nullable|string|max:255',
            'trips.*.end_city' => 'nullable|string|max:255',
            'trips.*.started_at' => 'required|date',
            'trips.*.ended_at' => 'required|date',
            'trips.*.points' => 'required|array|min:2|max:500',
            'trips.*.points.*.latitude' => 'required|numeric',
            'trips.*.points.*.longitude' => 'required|numeric',
            'trips.*.points.*.speed' => 'required|numeric|min:0',
            'trips.*.points.*.recorded_at' => 'required|date',
        ]);

        $results = [];

        DB::transaction(function () use ($request, &$results) {
            foreach ($request->trips as $tripData) {
                if (Carbon::parse($tripData['ended_at'])->lte(Carbon::parse($tripData['started_at']))) {
                    continue;
                }

                $trip = $request->user()->trips()->create([
                    'name' => $tripData['name'] ?? 'Offline trip',
                    'start_city' => $tripData['start_city'] ?? null,
                    'end_city' => $tripData['end_city'] ?? null,
                    'started_at' => $tripData['started_at'],
                    'ended_at' => $tripData['ended_at'],
                    'score' => 100,
                ]);

                $points = array_map(fn ($p) => [
                    'trip_id' => $trip->id,
                    'latitude' => $p['latitude'],
                    'longitude' => $p['longitude'],
                    'speed' => ($p['speed'] < 30 ? $p['speed'] * 3.6 : $p['speed']),
                    'heading' => $p['heading'] ?? null,
                    'altitude' => $p['altitude'] ?? null,
                    'recorded_at' => $p['recorded_at'],
                    'created_at' => now(),
                    'updated_at' => now(),
                ], $tripData['points']);

                foreach (array_chunk($points, 100) as $chunk) {
                    TripPoint::insert($chunk);
                }

                ProcessTripAnalytics::dispatch($trip);

                $results[] = [
                    'local_id' => $tripData['local_id'],
                    'trip_id' => $trip->id,
                    'status' => 'synced',
                ];
            }
        });

        return response()->json([
            'message' => count($results).' trip(s) synced from offline storage',
            'results' => $results,
        ]);
    }
}
